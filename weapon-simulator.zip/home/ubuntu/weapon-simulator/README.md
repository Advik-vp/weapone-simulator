# C++ Weapon Simulation Application

This project provides a C++ application for modeling, designing, and simulating various modern and futuristic weapon systems.

## Features

*   **Object-Oriented Design:** Uses inheritance and polymorphism for a flexible weapon class hierarchy (Firearm, Explosive, Missile, LaserWeapon).
*   **Customization:** Supports weapon attachments (Scope, Silencer, Extended Magazine) and parameter adjustments.
*   **Simulation:** Includes a basic physics simulation module for trajectory (placeholder), impact, and environmental factors (placeholder).
*   **CLI:** Provides a command-line interface for designing weapons, configuring simulation parameters, and running tests.
*   **Data Logging:** Records simulation results to CSV and JSON files for analysis.

## Project Structure

```
weapon-simulator/
├── build/              # Build directory (created by CMake)
├── include/            # Header files
│   ├── attachments/    # Attachment headers (Scope.h, etc.)
│   ├── core/           # Core classes (Weapon.h, Vector3D.h, Target.h, etc.)
│   ├── interface/      # CLI handler header (CLIHandler.h)
│   ├── logging/        # Logger header (Logger.h)
│   ├── simulation/     # Simulation headers (SimulationEngine.h, etc.)
│   └── weapons/        # Weapon type headers (Firearm.h, etc.)
├── src/                # Source files
│   ├── attachments/    # Attachment implementations
│   ├── core/           # Core class implementations
│   ├── interface/      # CLI handler implementation
│   ├── logging/        # Logger implementation
│   ├── simulation/     # Simulation engine implementation
│   ├── weapons/        # Weapon type implementations
│   └── main.cpp        # Main application entry point
├── CMakeLists.txt      # CMake build configuration
├── DESIGN.md           # Initial design document
└── README.md           # This file
```

## Prerequisites

*   A C++ compiler supporting C++11 or later (e.g., g++)
*   CMake (version 3.10 or later recommended)
*   Make (or another build system generator supported by CMake)

## Building the Application

1.  **Navigate to the project root directory:**
    ```bash
    cd path/to/weapon-simulator
    ```

2.  **Create a build directory and navigate into it:**
    ```bash
    mkdir build
    cd build
    ```

3.  **Run CMake to configure the project:**
    ```bash
    cmake ..
    ```

4.  **Compile the project using Make:**
    ```bash
    make
    ```
    This will create the executable `weapon_sim` (or `weapon_sim.exe` on Windows) in the `build` directory.

## Running the Application

1.  **Navigate to the build directory:**
    ```bash
    cd path/to/weapon-simulator/build
    ```

2.  **Run the executable:**
    ```bash
    ./weapon_sim
    ```

3.  Follow the prompts in the command-line interface to design weapons, configure the environment and target, and run simulations.

## Output

Simulation results are logged to `simulation_report.csv` and `simulation_report.json` in the directory where the application is run (the `build` directory by default).

## Notes

*   The physics simulation (especially trajectory calculation) is currently a placeholder and needs further development for realistic results.
*   Error handling is basic; more robust error checking could be added.
*   The CLI provides core functionality but could be expanded with more options and user-friendliness.

