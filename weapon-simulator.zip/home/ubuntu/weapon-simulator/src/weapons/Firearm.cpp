#include "weapons/Firearm.h"
#include "simulation/SimulationCommon.h"
#include "core/Target.h"
#include "core/Environment.h"
#include <iostream>
#include <cmath> // For std::pow, std::max
#include <random> // For basic randomness
#include <memory> // For std::make_unique
#include <utility> // For std::move

// Constructor
Firearm::Firearm(const std::string& name, double weight, double range, double cal, double rate, double rec, int magSize)
    : Weapon(name, weight, range),
      caliber(cal),
      fireRate(rate),
      recoil(rec),
      magazineCapacity(magSize),
      currentAmmo(magSize), // Start with a full magazine
      barrelHeat(0.0),
      coolingRate(1.0) // Example cooling rate
{}

// Copy Constructor (Handles deep copy of attachments)
Firearm::Firearm(const Firearm& other)
    : Weapon(other.name, other.weight, other.effectiveRange), // Copy base class members
      caliber(other.caliber),
      fireRate(other.fireRate),
      recoil(other.recoil),
      magazineCapacity(other.magazineCapacity),
      currentAmmo(other.currentAmmo),
      barrelHeat(other.barrelHeat),
      coolingRate(other.coolingRate)
{
    // Deep copy attachments from the base class vector
    attachments.clear(); // Ensure the vector is empty before copying
    for (const auto& attach : other.attachments) {
        if (attach) {
            attachments.push_back(attach->clone());
        }
    }
}


// Fire method
SimulationResult Firearm::fire(const Target& target, const Environment& env) {
    SimulationResult result;
    result.message = "Firing " + name + ".";

    if (currentAmmo <= 0) {
        result.message += " Click! Out of ammo.";
        result.hit = false;
        std::cout << result.message << std::endl;
        return result;
    }

    currentAmmo--;
    barrelHeat += 5.0; // Increase heat per shot (example value)

    // Basic Hit Calculation (Placeholder - needs proper trajectory physics)
    // Simulate accuracy based on range, recoil, heat, attachments?
    double distance = target.position.magnitude(); // Assuming target position is relative to origin (0,0,0)
    double hitProbability = 1.0;

    // Range penalty
    if (distance > effectiveRange) {
        hitProbability *= (effectiveRange / distance); // Simple linear falloff
    }

    // Recoil penalty (more recoil, less accurate subsequent shots - needs state)
    // For a single shot, recoil affects the *next* shot, not this one.

    // Heat penalty (overheated weapon is less accurate)
    hitProbability *= std::max(0.1, 1.0 - (barrelHeat / 100.0)); // Example heat effect

    // --- Attachment Effects on Firing (Example) ---
    // This is where attachments could modify the firing process itself
    // e.g., a scope might improve the base hit probability calculation
    // e.g., a silencer might reduce the audible range (not simulated here)

    // Random check for hit
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis(0.0, 1.0);

    if (dis(gen) <= hitProbability) {
        result.hit = true;
        result.impactPoint = target.position; // Assume direct hit for simplicity
        result.timeOfFlight = distance / 800.0; // Placeholder projectile speed (800 m/s)
        result.finalVelocity = 750.0; // Placeholder impact velocity
        result.message += " Target hit!";
    } else {
        result.hit = false;
        result.message += " Missed.";
        // Could calculate a miss distance/direction here
    }

    std::cout << result.message << " Ammo left: " << currentAmmo << ", Heat: " << barrelHeat << std::endl;
    // Simulate cooling over time (would happen in a proper simulation loop)
    // barrelHeat = std::max(0.0, barrelHeat - coolingRate * timeStep);

    return result;
}

// Reload method
void Firearm::reload() {
    std::cout << "Reloading " << name << "..." << std::endl;
    currentAmmo = magazineCapacity;
    barrelHeat = std::max(0.0, barrelHeat - 10.0); // Reloading might allow some cooling
    std::cout << "Reload complete. Ammo: " << currentAmmo << std::endl;
}

// Simulate impact damage
DamageReport Firearm::simulateImpact(const Vector3D& impactPoint, const Target& target) {
    DamageReport report;
    // This function should ideally be called only if fire() resulted in a hit.
    // We should pass the SimulationResult or check hit status before calling.
    // Assuming hit for this simplified version.

    // Basic damage model based on caliber
    report.damageDealt = caliber * 5.0; // Example damage calculation
    report.penetrationDepth = caliber / 10.0; // Example penetration
    report.effectDescription = "Kinetic impact.";

    // --- Attachment Effects on Impact (Example) ---
    // e.g., special ammo types loaded via an attachment?

    // Check if target is destroyed (simplified)
    // report.targetDestroyed = (target.health - report.damageDealt <= 0);

    std::cout << "Impact by " << name << " at (" << impactPoint.x << "," << impactPoint.y << "," << impactPoint.z << "): "
              << "Damage=" << report.damageDealt << ", Penetration=" << report.penetrationDepth << std::endl;
    return report;
}

// Display stats
void Firearm::displayStats() const {
    std::cout << "--- Firearm Stats: " << name << " ---" << std::endl;
    std::cout << "  Type: Firearm" << std::endl;
    std::cout << "  Weight: " << weight << " kg" << std::endl;
    std::cout << "  Effective Range: " << effectiveRange << " m" << std::endl;
    std::cout << "  Caliber: " << caliber << " mm" << std::endl;
    std::cout << "  Fire Rate: " << fireRate << " RPM" << std::endl;
    std::cout << "  Recoil: " << recoil << std::endl;
    std::cout << "  Magazine Capacity: " << magazineCapacity << std::endl;
    std::cout << "  Current Ammo: " << currentAmmo << std::endl;
    std::cout << "  Barrel Heat: " << barrelHeat << std::endl;
    if (!attachments.empty()) {
        std::cout << "  Attachments:" << std::endl;
        for (const auto& attach : attachments) {
            if(attach) std::cout << "    - " << attach->getName() << std::endl;
            else std::cout << "    - [Invalid Attachment Pointer]" << std::endl;
        }
    }
    std::cout << "-------------------------" << std::endl;
}

// Clone method for deep copying
std::unique_ptr<Weapon> Firearm::clone() const {
    // Use the custom copy constructor which handles deep copying attachments
    return std::make_unique<Firearm>(*this);
}

// Getters/Setters specific to Firearm
int Firearm::getMagazineCapacity() const {
    return magazineCapacity;
}

void Firearm::setMagazineCapacity(int capacity) {
    magazineCapacity = capacity;
    // Adjust current ammo if necessary (e.g., clip current ammo to new max)
    if (currentAmmo > magazineCapacity) {
        currentAmmo = magazineCapacity;
    }
}

