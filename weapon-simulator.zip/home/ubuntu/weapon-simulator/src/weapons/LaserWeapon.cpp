#include "weapons/LaserWeapon.h"
#include "simulation/SimulationCommon.h"
#include "core/Target.h"
#include "core/Environment.h"
#include <iostream>
#include <cmath> // For std::min, std::max
#include <memory> // For std::make_unique
#include <utility> // For std::move

// Constructor
LaserWeapon::LaserWeapon(const std::string& name, double weight, double range,
                         double power, double duration, double energyCostPerShot,
                         double heatGen, double maxHeatCap, double coolRate, double energyCap)
    : Weapon(name, weight, range),
      powerOutput(power),
      beamDuration(duration),
      energyPerShot(energyCostPerShot),
      heatGeneratedPerShot(heatGen),
      maxHeatCapacity(maxHeatCap),
      coolingRatePerSecond(coolRate),
      energySourceCapacity(energyCap),
      currentEnergy(energyCap),
      currentHeat(0.0)
{}

// Copy Constructor (Handles deep copy of attachments)
LaserWeapon::LaserWeapon(const LaserWeapon& other)
    : Weapon(other.name, other.weight, other.effectiveRange), // Copy base class members
      powerOutput(other.powerOutput),
      beamDuration(other.beamDuration),
      energyPerShot(other.energyPerShot),
      heatGeneratedPerShot(other.heatGeneratedPerShot),
      maxHeatCapacity(other.maxHeatCapacity),
      coolingRatePerSecond(other.coolingRatePerSecond),
      energySourceCapacity(other.energySourceCapacity),
      currentEnergy(other.currentEnergy),
      currentHeat(other.currentHeat)
{
    // Deep copy attachments from the base class vector
    attachments.clear(); // Ensure the vector is empty before copying
    for (const auto& attach : other.attachments) {
        if (attach) {
            attachments.push_back(attach->clone());
        }
    }
}

// Fire method
SimulationResult LaserWeapon::fire(const Target& target, const Environment& env) {
    SimulationResult result;
    result.message = "Firing laser: " + name + ".";

    if (currentEnergy < energyPerShot) {
        result.message += " Insufficient energy.";
        result.hit = false;
        std::cout << result.message << std::endl;
        return result;
    }
    if (currentHeat >= maxHeatCapacity) {
        result.message += " Weapon overheated, cannot fire.";
        result.hit = false;
        std::cout << result.message << std::endl;
        return result;
    }

    currentEnergy -= energyPerShot;
    currentHeat += heatGeneratedPerShot;

    // Laser Simulation: Instant hit within range, affected by atmosphere?
    double distance = target.position.magnitude();

    // Atmospheric scattering/absorption could reduce effective power over distance
    // Simplified: Assume full power delivery within effectiveRange
    if (distance <= effectiveRange) {
        result.hit = true;
        result.impactPoint = target.position; // Laser hits instantly
        result.timeOfFlight = 0.0; // Or distance / speed_of_light, effectively zero
        result.finalVelocity = 0; // Not applicable for laser
        result.message += " Target hit instantly.";
    } else {
        result.hit = false;
        result.message += " Target out of effective range.";
    }

    // Simulate cooling (would happen over time in a real sim loop)
    // currentHeat = std::max(0.0, currentHeat - coolingRatePerSecond * timeStep);

    std::cout << result.message << " Energy left: " << currentEnergy << "/" << energySourceCapacity << ", Heat: " << currentHeat << "/" << maxHeatCapacity << std::endl;

    return result;
}

// Reload method (represents recharging or replacing energy source)
void LaserWeapon::reload() {
    std::cout << "Recharging energy source for " << name << "..." << std::endl;
    // For simplicity, instantly recharge. A real sim might take time.
    currentEnergy = energySourceCapacity;
    std::cout << "Recharge complete. Energy: " << currentEnergy << std::endl;
}

// Simulate impact damage (thermal damage)
DamageReport LaserWeapon::simulateImpact(const Vector3D& impactPoint, const Target& target) {
    DamageReport report;
    // This function should ideally be called only if fire() resulted in a hit.
    // Assuming hit for this simplified version.

    // Damage based on power delivered over duration, considering target material?
    double energyDelivered = powerOutput * beamDuration; // Joules (kW * s)
    report.damageDealt = energyDelivered / 1000.0; // Arbitrary scaling factor for damage
    report.heatTransferred = energyDelivered / 2.0; // Example heat transfer
    report.effectDescription = "Thermal ablation/melting.";
    // report.targetDestroyed = (target.health - report.damageDealt <= 0);

    std::cout << "Laser impact from " << name << " at (" << impactPoint.x << "," << impactPoint.y << "," << impactPoint.z << "): "
              << "Damage=" << report.damageDealt << ", Heat Transfer=" << report.heatTransferred << std::endl;

    return report;
}

// Display stats
void LaserWeapon::displayStats() const {
    std::cout << "--- Laser Weapon Stats: " << name << " ---" << std::endl;
    std::cout << "  Type: Laser Weapon" << std::endl;
    std::cout << "  Weight: " << weight << " kg" << std::endl;
    std::cout << "  Effective Range: " << effectiveRange << " m" << std::endl;
    std::cout << "  Power Output: " << powerOutput << " kW" << std::endl;
    std::cout << "  Beam Duration: " << beamDuration << " s" << std::endl;
    std::cout << "  Energy Per Shot: " << energyPerShot << " J" << std::endl;
    std::cout << "  Energy Capacity: " << energySourceCapacity << " J" << std::endl;
    std::cout << "  Current Energy: " << currentEnergy << " J" << std::endl;
    std::cout << "  Heat Generated/Shot: " << heatGeneratedPerShot << std::endl;
    std::cout << "  Max Heat Capacity: " << maxHeatCapacity << std::endl;
    std::cout << "  Current Heat: " << currentHeat << std::endl;
    std::cout << "  Cooling Rate: " << coolingRatePerSecond << " /s" << std::endl;
    if (!attachments.empty()) {
        std::cout << "  Attachments:" << std::endl;
        for (const auto& attach : attachments) {
            if(attach) std::cout << "    - " << attach->getName() << std::endl;
            else std::cout << "    - [Invalid Attachment Pointer]" << std::endl;
        }
    }
    std::cout << "---------------------------" << std::endl;
}

// Clone method for deep copying
std::unique_ptr<Weapon> LaserWeapon::clone() const {
    // Use the custom copy constructor which handles deep copying attachments
    return std::make_unique<LaserWeapon>(*this);
}

