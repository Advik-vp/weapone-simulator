#include "weapons/Explosive.h"
#include "simulation/SimulationCommon.h"
#include "core/Target.h"
#include "core/Environment.h"
#include <iostream>
#include <cmath> // For std::pow
#include <memory> // For std::make_unique
#include <utility> // For std::move

// Constructor
Explosive::Explosive(const std::string& name, double weight, double range,
                     const std::string& type, double radius, double dmg,
                     ExplosiveDeliveryMethod method, double fuseTime)
    : Weapon(name, weight, range),
      payloadType(type),
      blastRadius(radius),
      maxDamage(dmg),
      deliveryMethod(method),
      fuseTimer(fuseTime),
      isArmed(false) // Explosives usually start unarmed
{}

// Copy Constructor (Handles deep copy of attachments)
Explosive::Explosive(const Explosive& other)
    : Weapon(other.name, other.weight, other.effectiveRange), // Copy base class members
      payloadType(other.payloadType),
      blastRadius(other.blastRadius),
      maxDamage(other.maxDamage),
      deliveryMethod(other.deliveryMethod),
      fuseTimer(other.fuseTimer),
      isArmed(other.isArmed) // Copy state
{
    // Deep copy attachments from the base class vector
    attachments.clear(); // Ensure the vector is empty before copying
    for (const auto& attach : other.attachments) {
        if (attach) {
            attachments.push_back(attach->clone());
        }
    }
}

// Fire method (represents deploying/throwing/launching the explosive)
SimulationResult Explosive::fire(const Target& target, const Environment& env) {
    SimulationResult result;
    result.message = "Deploying explosive: " + name + ".";
    isArmed = true; // Arm the explosive upon firing/deployment

    // Simplified simulation: Assume it reaches the target area or intended point.
    // A real simulation would calculate trajectory based on deliveryMethod.
    double distance = target.position.magnitude();

    if (deliveryMethod == ExplosiveDeliveryMethod::THROWN && distance > effectiveRange) {
        result.hit = false;
        result.message += " Target out of throwing range.";
        isArmed = false; // Failed deployment
    } else if (deliveryMethod == ExplosiveDeliveryMethod::LAUNCHED && distance > effectiveRange) {
        result.hit = false;
        result.message += " Target out of launch range.";
        isArmed = false; // Failed deployment
    } else {
        // Assume successful deployment near the target for now
        result.hit = true; // Hit means successful deployment/arrival, not necessarily detonation damage yet
        result.impactPoint = target.position; // Simplified: lands exactly at target
        result.timeOfFlight = (deliveryMethod == ExplosiveDeliveryMethod::PLACED) ? 0.0 : distance / 50.0; // Placeholder speed
        result.finalVelocity = 0; // Velocity upon impact/placement
        result.message += " Deployed near target.";
        if (fuseTimer > 0) {
             result.message += " Fuse set for " + std::to_string(fuseTimer) + "s.";
             // In a time-based simulation, detonation would happen later.
             // For this simple model, we might trigger impact simulation immediately if fuse is 0 (impact fuse)
        } else {
             result.message += " Impact fuse.";
        }
    }

    std::cout << result.message << std::endl;
    // Note: The actual explosion/damage happens in simulateImpact
    return result;
}

// Reload method (doesn't really apply to single-use explosives like grenades)
void Explosive::reload() {
    std::cout << name << " is a single-use explosive and cannot be reloaded in the traditional sense." << std::endl;
    // Could represent getting another grenade, but that's inventory management.
}

// Simulate impact/detonation damage
DamageReport Explosive::simulateImpact(const Vector3D& impactPoint, const Target& target) {
    DamageReport report;
    if (!isArmed) { // Can only detonate if armed (successfully deployed)
        report.damageDealt = 0;
        report.effectDescription = "Explosive not armed.";
        report.targetDestroyed = false;
        return report;
    }

    // Calculate distance from explosion center (impactPoint) to target center
    double distanceToTarget = (target.position - impactPoint).magnitude();

    if (distanceToTarget <= blastRadius) {
        // Simple damage falloff model (linear)
        report.damageDealt = maxDamage * std::max(0.0, (1.0 - (distanceToTarget / blastRadius))); // Ensure non-negative
        report.blastRadiusAffected = blastRadius;
        report.effectDescription = "Caught in blast radius.";
        // report.targetDestroyed = (target.health - report.damageDealt <= 0);
    } else {
        report.damageDealt = 0;
        report.effectDescription = "Outside blast radius.";
        report.targetDestroyed = false;
    }

    std::cout << "Explosion from " << name << " at (" << impactPoint.x << "," << impactPoint.y << "," << impactPoint.z << "): "
              << "Damage=" << report.damageDealt << ", Effect: " << report.effectDescription << std::endl;

    isArmed = false; // Explosive is now spent
    return report;
}

// Display stats
void Explosive::displayStats() const {
    std::cout << "--- Explosive Stats: " << name << " ---" << std::endl;
    std::cout << "  Type: Explosive" << std::endl;
    std::cout << "  Weight: " << weight << " kg" << std::endl;
    std::cout << "  Range/Deployment: " << effectiveRange << " m" << std::endl;
    std::cout << "  Payload Type: " << payloadType << std::endl;
    std::cout << "  Blast Radius: " << blastRadius << " m" << std::endl;
    std::cout << "  Max Damage: " << maxDamage << std::endl;
    std::cout << "  Delivery Method: ";
    switch(deliveryMethod) {
        case ExplosiveDeliveryMethod::THROWN: std::cout << "Thrown"; break;
        case ExplosiveDeliveryMethod::LAUNCHED: std::cout << "Launched"; break;
        case ExplosiveDeliveryMethod::PLACED: std::cout << "Placed"; break;
    }
    std::cout << std::endl;
    std::cout << "  Fuse Time: " << fuseTimer << " s" << std::endl;
    std::cout << "  Armed: " << (isArmed ? "Yes" : "No") << std::endl;
    if (!attachments.empty()) {
        std::cout << "  Attachments:" << std::endl;
        for (const auto& attach : attachments) {
            if(attach) std::cout << "    - " << attach->getName() << std::endl;
            else std::cout << "    - [Invalid Attachment Pointer]" << std::endl;
        }
    }
    std::cout << "-------------------------" << std::endl;
}

// Clone method for deep copying
std::unique_ptr<Weapon> Explosive::clone() const {
    // Use the custom copy constructor which handles deep copying attachments
    return std::make_unique<Explosive>(*this);
}

// Add an arm() method to Explosive for the Missile to use
void Explosive::arm() {
    isArmed = true;
}

// Add getters to Explosive needed by Missile::displayStats
const std::string& Explosive::getPayloadType() const {
    return payloadType;
}
double Explosive::getBlastRadius() const {
    return blastRadius;
}
double Explosive::getMaxDamage() const {
    return maxDamage;
}

