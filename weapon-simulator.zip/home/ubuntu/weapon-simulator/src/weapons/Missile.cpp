#include "weapons/Missile.h"
#include "simulation/SimulationCommon.h"
#include "core/Target.h"
#include "core/Environment.h"
#include <iostream>
#include <cmath> // For distance calculation
#include <memory> // For std::make_unique
#include <utility> // For std::move
#include <limits> // For numeric_limits

// Constructor
Missile::Missile(const std::string& name, double weight, double range,
                 MissileGuidanceSystem guide, double spd, double fuelCap, double turn,
                 std::unique_ptr<Explosive> warhead)
    : Weapon(name, weight, range),
      guidanceSystem(guide),
      maxSpeed(spd),
      fuelCapacity(fuelCap),
      currentFuel(fuelCap),
      turnRate(turn),
      payload(std::move(warhead)), // Take ownership of the payload
      isLaunched(false),
      targetLocked(false),
      position({0,0,0}) // Initialize position
{}

// Copy Constructor (Handles deep copy of attachments and payload)
Missile::Missile(const Missile& other)
    : Weapon(other.name, other.weight, other.effectiveRange), // Copy base class members
      guidanceSystem(other.guidanceSystem),
      maxSpeed(other.maxSpeed),
      fuelCapacity(other.fuelCapacity),
      currentFuel(other.currentFuel),
      turnRate(other.turnRate),
      isLaunched(other.isLaunched),
      targetLocked(other.targetLocked),
      position(other.position)
{
    // Deep copy the payload
    if (other.payload) {
        // Clone the payload (which should return unique_ptr<Weapon>)
        auto clonedPayloadWeapon = other.payload->clone();
        // Dynamic cast to check if it's actually an Explosive and release ownership
        Explosive* rawPayload = dynamic_cast<Explosive*>(clonedPayloadWeapon.release());
        if (rawPayload) {
            payload = std::unique_ptr<Explosive>(rawPayload);
        } else {
            // Handle error: the cloned payload wasn't an Explosive as expected.
            // This might indicate a logic error in how payloads are handled.
            std::cerr << "Error: Failed to cast cloned payload to Explosive during Missile copy construction." << std::endl;
            // payload remains nullptr
        }
    } else {
        payload = nullptr;
    }

    // Deep copy attachments from the base class vector
    attachments.clear(); // Ensure the vector is empty before copying
    for (const auto& attach : other.attachments) {
        if (attach) {
            attachments.push_back(attach->clone());
        }
    }
}


// Fire method (launch the missile)
SimulationResult Missile::fire(const Target& target, const Environment& env) {
    SimulationResult result;
    result.message = "Launching missile: " + name + ".";

    if (isLaunched) {
        result.message += " Already launched!";
        result.hit = false; // Cannot launch again
        std::cout << result.message << std::endl;
        return result;
    }

    if (currentFuel <= 0) {
        result.message += " Out of fuel, cannot launch.";
        result.hit = false;
        std::cout << result.message << std::endl;
        return result;
    }

    isLaunched = true;
    targetLocked = (guidanceSystem != MissileGuidanceSystem::UNGUIDED); // Assume lock if guided
    result.message += " Launched towards target.";

    // Simplified Simulation: Straight line flight, fuel consumption, basic guidance check
    double distance = (target.position - position).magnitude(); // Distance from current missile pos to target
    double timeToTarget = (maxSpeed > 0) ? distance / maxSpeed : std::numeric_limits<double>::infinity(); // Ideal time
    double fuelNeeded = timeToTarget * 1.0; // Placeholder fuel consumption rate (e.g., 1 unit/sec)

    if (distance > effectiveRange) {
        result.message += " Target potentially out of maximum range.";
        // Continue simulation, might run out of fuel
    }

    if (fuelNeeded > currentFuel) {
        result.hit = false;
        // Calculate impact point based on fuel available
        double flightTimePossible = currentFuel / 1.0; // Time based on consumption rate
        double distanceCovered = flightTimePossible * maxSpeed;
        Vector3D direction = (target.position - position).normalized(); // Assuming missile starts at `position`
        result.impactPoint = position + direction * distanceCovered;
        result.timeOfFlight = flightTimePossible;
        result.finalVelocity = maxSpeed;
        result.message += " Ran out of fuel before reaching target.";
        currentFuel = 0;
    } else {
        // Assume guided missiles hit if within range and fuel
        // Unguided might miss based on other factors (not simulated here)
        if (guidanceSystem != MissileGuidanceSystem::UNGUIDED) {
            result.hit = true;
            result.impactPoint = target.position;
            result.timeOfFlight = timeToTarget;
            result.finalVelocity = maxSpeed;
            result.message += " Guided trajectory successful. Impact imminent.";
        } else {
            // Basic check for unguided - could add deviation
            result.hit = true; // Simplified: Assume hit for now
            result.impactPoint = target.position;
            result.timeOfFlight = timeToTarget;
            result.finalVelocity = maxSpeed;
            result.message += " Unguided trajectory. Impact imminent.";
        }
        currentFuel -= fuelNeeded;
    }

    std::cout << result.message << " Fuel left: " << currentFuel << std::endl;
    // Detonation happens in simulateImpact
    return result;
}

// Reload method (Missiles are typically single-shot from a launcher)
void Missile::reload() {
    std::cout << name << " is a single-use missile. Requires reloading the launcher system (not simulated)." << std::endl;
    // Resetting state for potential re-use in simulation if needed
    // isLaunched = false;
    // currentFuel = fuelCapacity;
    // targetLocked = false;
}

// Simulate impact damage (delegates to payload)
DamageReport Missile::simulateImpact(const Vector3D& impactPoint, const Target& target) {
    DamageReport report; // Default initialize
    if (!isLaunched) {
        report.damageDealt = 0.0;
        report.effectDescription = "Missile not launched.";
        report.targetDestroyed = false;
        return report; // Return explicitly initialized report
    }
    if (!payload) {
        report.damageDealt = 0.0;
        report.effectDescription = "Missile has no payload.";
        report.targetDestroyed = false;
        return report; // Return explicitly initialized report
    }

    // Simulate the payload's impact (usually an explosion)
    // We need to temporarily "arm" the payload for its simulation
    payload->arm(); // Assuming an arm() method exists or simulateImpact handles it
    report = payload->simulateImpact(impactPoint, target); // Get report from payload
    // Prepend missile info to the description from the payload
    report.effectDescription = "Missile payload ( " + payload->getName() + " ) detonated: " + report.effectDescription;

    std::cout << "Missile " << name << " impacted. Payload effect: " << report.effectDescription << std::endl;

    isLaunched = false; // Missile is spent after impact

    return report;
}

// Display stats
void Missile::displayStats() const {
    std::cout << "--- Missile Stats: " << name << " ---" << std::endl;
    std::cout << "  Type: Missile" << std::endl;
    std::cout << "  Weight: " << weight << " kg" << std::endl;
    std::cout << "  Max Range: " << effectiveRange << " m" << std::endl;
    std::cout << "  Guidance: ";
    switch(guidanceSystem) {
        case MissileGuidanceSystem::UNGUIDED: std::cout << "Unguided"; break;
        case MissileGuidanceSystem::INFRARED: std::cout << "Infrared (IR)"; break;
        case MissileGuidanceSystem::RADAR: std::cout << "Radar"; break;
        case MissileGuidanceSystem::LASER: std::cout << "Laser Guided"; break;
        case MissileGuidanceSystem::GPS: std::cout << "GPS Guided"; break;
    }
    std::cout << std::endl;
    std::cout << "  Max Speed: " << maxSpeed << " m/s" << std::endl;
    std::cout << "  Fuel Capacity: " << fuelCapacity << std::endl;
    std::cout << "  Current Fuel: " << currentFuel << std::endl;
    std::cout << "  Turn Rate: " << turnRate << " deg/s" << std::endl;
    std::cout << "  Launched: " << (isLaunched ? "Yes" : "No") << std::endl;
    if (payload) {
        std::cout << "  Payload: " << payload->getName() << " (" << payload->getPayloadType() << ")" << std::endl;
        std::cout << "    Blast Radius: " << payload->getBlastRadius() << " m" << std::endl;
        std::cout << "    Max Damage: " << payload->getMaxDamage() << std::endl;
    } else {
        std::cout << "  Payload: None" << std::endl;
    }
    if (!attachments.empty()) {
        std::cout << "  Attachments:" << std::endl;
        for (const auto& attach : attachments) {
             if(attach) std::cout << "    - " << attach->getName() << std::endl;
             else std::cout << "    - [Invalid Attachment Pointer]" << std::endl;
        }
    }
    std::cout << "-------------------------" << std::endl;
}

// Clone method for deep copying
std::unique_ptr<Weapon> Missile::clone() const {
    // Use the custom copy constructor which handles deep copying payload and attachments
    return std::make_unique<Missile>(*this);
}

// Add an arm() method to Explosive for the Missile to use
// This definition should be in Explosive.cpp, but placing it here temporarily
// if Explosive.cpp wasn't updated correctly.
// void Explosive::arm() {
//     isArmed = true;
// }

// Add getters to Explosive needed by Missile::displayStats
// These definitions should be in Explosive.cpp
// const std::string& Explosive::getPayloadType() const {
//     return payloadType;
// }
// double Explosive::getBlastRadius() const {
//     return blastRadius;
// }
// double Explosive::getMaxDamage() const {
//     return maxDamage;
// }

