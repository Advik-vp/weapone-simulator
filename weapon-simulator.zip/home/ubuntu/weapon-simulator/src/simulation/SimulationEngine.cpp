#include "simulation/SimulationEngine.h"
#include "weapons/Firearm.h"
#include "weapons/Explosive.h"
#include "weapons/Missile.h"
#include "weapons/LaserWeapon.h"
#include <cmath> // For sqrt, pow, etc.
#include <iostream> // For debugging output
#include <cstdlib> // For rand(), RAND_MAX
#include <vector> // For trajectory path (if implemented)

SimulationEngine::SimulationEngine() {
    // Initialize strategies if using strategy pattern
    // std::cout << "Simulation Engine Initialized." << std::endl;
}

SimulationEngine::~SimulationEngine() {
    // Clean up resources if needed
    // std::cout << "Simulation Engine Destroyed." << std::endl;
}

// Main simulation orchestrator
SimulationResult SimulationEngine::runSimulation(Weapon& weapon, Target& target, const Environment& env) {
    // Determine weapon type and call appropriate simulation logic
    // Using dynamic_cast for type checking. Consider Visitor pattern for better OO design.
    if (auto* firearm = dynamic_cast<Firearm*>(&weapon)) {
        return simulateFirearmShot(firearm, target, env);
    } else if (auto* explosive = dynamic_cast<Explosive*>(&weapon)) {
        return simulateExplosiveLaunch(explosive, target, env);
    } else if (auto* missile = dynamic_cast<Missile*>(&weapon)) {
        return simulateMissileLaunch(missile, target, env);
    } else if (auto* laser = dynamic_cast<LaserWeapon*>(&weapon)) {
        return simulateLaserFire(laser, target, env);
    } else {
        std::cerr << "Error: Unknown weapon type in simulation!" << std::endl;
        SimulationResult result;
        result.message = "Error: Unknown weapon type";
        return result;
    }
}

// --- Placeholder Simulation Logic for Different Weapon Types ---
// These need actual physics implementations

SimulationResult SimulationEngine::simulateFirearmShot(Firearm* firearm, const Target& target, const Environment& env) {
    std::cout << "Simulating Firearm Shot: " << firearm->getName() << std::endl;
    // Use the weapon's own fire method which contains more detailed logic
    SimulationResult result = firearm->fire(target, env);
    
    // If the fire resulted in a hit, simulate the impact
    if (result.hit) {
        DamageReport damage = firearm->simulateImpact(result.impactPoint, target);
        // Apply damage to target (Target health needs to be mutable or handled externally)
        // target.applyDamage(damage.damageDealt);
        result.message += " (" + std::to_string(damage.damageDealt) + " damage)";
        // if (target.isDestroyed()) result.message = "Target Destroyed";
    }
    
    return result;
}

SimulationResult SimulationEngine::simulateExplosiveLaunch(Explosive* explosive, const Target& target, const Environment& env) {
    std::cout << "Simulating Explosive Launch/Throw: " << explosive->getName() << std::endl;
    // Use the weapon's own fire method
    SimulationResult result = explosive->fire(target, env);

    // If the deployment was successful (hit=true), simulate the impact (detonation)
    if (result.hit) {
        DamageReport damage = explosive->simulateImpact(result.impactPoint, target);
        // Apply area damage based on blast radius and distance from impactPoint
        // target.applyAreaDamage(damage.damageDealt, damage.blastRadiusAffected, result.impactPoint);
        result.message += " (" + std::to_string(damage.damageDealt) + " area damage)";
        // if (target.isDestroyed()) result.message = "Target Destroyed by blast";
    }

    return result;
}

SimulationResult SimulationEngine::simulateMissileLaunch(Missile* missile, const Target& target, const Environment& env) {
    std::cout << "Simulating Missile Launch: " << missile->getName() << std::endl;
    // Use the weapon's own fire method
    SimulationResult result = missile->fire(target, env);

    // If the missile hit (reached target or ran out of fuel near it), simulate payload impact
    if (result.hit) { // Note: Missile's fire() sets hit=true if it reaches target
        DamageReport damage = missile->simulateImpact(result.impactPoint, target);
        // Apply damage from payload
        // target.applyDamage(damage.damageDealt); // Or area damage if payload is explosive
        result.message += " (" + std::to_string(damage.damageDealt) + " payload damage)";
        // if (target.isDestroyed()) result.message = "Target Destroyed by missile";
    } else if (!result.message.empty() && result.message.find("Ran out of fuel") != std::string::npos) {
        // Handle case where missile ran out of fuel but didn't hit
        // Optionally simulate impact at the point where fuel ran out
        DamageReport damage = missile->simulateImpact(result.impactPoint, target); // Payload might still detonate
        result.message += " (Payload detonated at impact point)";
    }

    return result;
}

SimulationResult SimulationEngine::simulateLaserFire(LaserWeapon* laser, const Target& target, const Environment& env) {
    std::cout << "Simulating Laser Fire: " << laser->getName() << std::endl;
    // Use the weapon's own fire method
    SimulationResult result = laser->fire(target, env);

    // If the laser hit, simulate the impact
    if (result.hit) {
        DamageReport damage = laser->simulateImpact(result.impactPoint, target);
        // Apply thermal damage
        // target.applyDamage(damage.damageDealt);
        result.message += " (" + std::to_string(damage.damageDealt) + " thermal damage)";
        // if (target.isDestroyed()) result.message = "Target Destroyed by laser";
    }
    return result;
}

// --- Placeholder Physics Calculations ---
// Ensure the signature matches the header file exactly
Vector3D SimulationEngine::calculateBallisticTrajectory(
    const Vector3D& startPos, 
    const Vector3D& initialVelocity, 
    double mass, 
    double dragCoefficient, 
    double crossSectionalArea, 
    const Environment& env, 
    double timeStep, 
    double maxTime, 
    Vector3D& impactPoint, // Output parameter for impact point
    double& timeOfFlight) // Output parameter for time of flight
{
    std::cout << "Calculating Ballistic Trajectory (Placeholder)..." << std::endl;
    // Needs implementation (e.g., numerical integration like Euler or RK4)
    // Consider gravity, drag, wind
    
    // Placeholder implementation: Assume straight line, no gravity/drag
    // This is highly inaccurate and needs replacement.
    Vector3D currentPos = startPos;
    Vector3D currentVel = initialVelocity;
    timeOfFlight = 0.0;
    bool hitGround = false;

    for (double t = 0; t < maxTime; t += timeStep) {
        // Update position based on velocity
        currentPos += currentVel * timeStep;
        timeOfFlight += timeStep;

        // Simple ground check (y=0)
        if (currentPos.y <= 0) {
            impactPoint = currentPos;
            impactPoint.y = 0; // Ensure impact is exactly at ground level
            hitGround = true;
            break;
        }
        
        // In a real simulation, update velocity based on forces (gravity, drag)
        // Vector3D gravityForce = {0, -env.gravity * mass, 0};
        // Vector3D dragForce = calculateDrag(currentVel, dragCoefficient, crossSectionalArea, env.airDensity);
        // Vector3D netForce = gravityForce + dragForce + env.wind; // Assuming wind is a force vector
        // Vector3D acceleration = netForce / mass;
        // currentVel += acceleration * timeStep;
    }

    if (!hitGround) {
        // If maxTime reached without hitting ground, set impact point to last position
        impactPoint = currentPos;
        // Indicate that it might not be a true impact
    }

    return impactPoint; // Return the final impact point
}

bool SimulationEngine::checkCollision(const Vector3D& projectilePos, const Target& target) {
    std::cout << "Checking Collision (Placeholder)..." << std::endl;
    // Simple bounding sphere collision check
    double distanceSq = (projectilePos - target.position).magnitudeSquared();
    // Correctly calculate squared radius using target.radius (which is a double)
    double targetRadiusSq = std::pow(target.radius, 2.0); // Use pow() or target.radius * target.radius
    return distanceSq <= targetRadiusSq;
}

