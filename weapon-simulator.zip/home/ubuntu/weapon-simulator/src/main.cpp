#include "interface/CLIHandler.h"
#include <iostream>

int main() {
    // Seed the random number generator (used in placeholder simulation logic)
    srand(static_cast<unsigned int>(time(0)));

    std::cout << "Starting Weapon Simulation Application..." << std::endl;
    
    CLIHandler cli;
    cli.run(); // Start the command-line interface loop

    std::cout << "Weapon Simulation Application Finished." << std::endl;
    return 0;
}

