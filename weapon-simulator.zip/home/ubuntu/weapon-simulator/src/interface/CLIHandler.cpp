#include "interface/CLIHandler.h"
#include "simulation/SimulationEngine.h"
#include "core/Weapon.h"
#include "core/Target.h"
#include "core/Environment.h"
#include "weapons/Firearm.h"
#include "weapons/Explosive.h"
#include "weapons/Missile.h"
#include "weapons/LaserWeapon.h"
#include <iostream>
#include <limits> // Required for numeric_limits
#include <stdexcept> // Required for exception handling in input
#include <memory> // For std::make_unique
#include <vector>
#include <string>

// Constructor
CLIHandler::CLIHandler() {
    simEngine = std::make_unique<SimulationEngine>();
    // Initialize default environment and target
    currentEnvironment = Environment();
    currentTarget = Target(Vector3D(100, 0, 0)); // Default target at 100m distance
    std::cout << "Weapon Simulation CLI Initialized." << std::endl;
}

// Destructor
CLIHandler::~CLIHandler() {
    std::cout << "Exiting Weapon Simulation CLI." << std::endl;
}

// Main execution loop
void CLIHandler::run() {
    int choice = 0;
    do {
        displayMainMenu();
        choice = getUserChoice(1, 7);
        try {
            processMainMenuChoice(choice);
        } catch (const std::exception& e) {
            std::cerr << "Error: " << e.what() << std::endl;
        }
    } while (choice != 7); // 7 is the exit option
}

// Display the main menu options
void CLIHandler::displayMainMenu() const {
    std::cout << "\n--- Main Menu ---" << std::endl;
    std::cout << "1. Design New Weapon" << std::endl;
    std::cout << "2. View Designed Weapons" << std::endl;
    std::cout << "3. Configure Environment" << std::endl;
    std::cout << "4. Configure Target" << std::endl;
    std::cout << "5. Run Simulation" << std::endl;
    std::cout << "6. Compare Weapons (Placeholder)" << std::endl;
    std::cout << "7. Exit" << std::endl;
    std::cout << "Enter your choice: ";
}

// Process the user's choice from the main menu
void CLIHandler::processMainMenuChoice(int choice) {
    switch (choice) {
        case 1:
            handleWeaponDesign();
            break;
        case 2:
            handleViewWeapons();
            break;
        case 3:
            handleConfigureEnvironment();
            break;
        case 4:
            handleConfigureTarget();
            break;
        case 5:
            handleRunSimulation();
            break;
        case 6:
            handleCompareWeapons();
            break;
        case 7:
            std::cout << "Exiting..." << std::endl;
            break;
        default:
            std::cout << "Invalid choice. Please try again." << std::endl;
            break;
    }
}

// --- Input Helper Functions ---

int CLIHandler::getUserChoice(int minChoice, int maxChoice) const {
    int choice = 0;
    while (!(std::cin >> choice) || choice < minChoice || choice > maxChoice) {
        std::cout << "Invalid input. Please enter a number between " << minChoice << " and " << maxChoice << ": ";
        std::cin.clear(); // Clear error flags
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discard invalid input
    }
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discard the newline character
    return choice;
}

double CLIHandler::getUserDouble(const std::string& prompt) const {
    double value = 0.0;
    std::cout << prompt;
    while (!(std::cin >> value)) {
        std::cout << "Invalid input. Please enter a number: ";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    return value;
}

int CLIHandler::getUserInt(const std::string& prompt) const {
    int value = 0;
    std::cout << prompt;
    while (!(std::cin >> value)) {
        std::cout << "Invalid input. Please enter an integer: ";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    return value;
}

std::string CLIHandler::getUserString(const std::string& prompt) const {
    std::string value = "";
    std::cout << prompt;
    // Clear the buffer before getline if previous input was >>
    // This check handles cases where getUserChoice, Int, or Double might leave a newline
    if (std::cin.peek() == '\n') {
        std::cin.ignore();
    }
    std::getline(std::cin, value);
    // Basic validation: ensure not empty? 
    while (value.empty()) {
        std::cout << "Input cannot be empty. Please try again: ";
        std::getline(std::cin, value);
    }
    return value;
}

// --- Weapon Creation Helpers ---

std::unique_ptr<Weapon> CLIHandler::createFirearm() {
    std::cout << "\n-- Designing Firearm --" << std::endl;
    std::string name = getUserString("Enter weapon name: ");
    double weight = getUserDouble("Enter weight (kg): ");
    double range = getUserDouble("Enter effective range (m): ");
    double caliber = getUserDouble("Enter caliber (mm): ");
    double fireRate = getUserDouble("Enter fire rate (RPM): ");
    double recoil = getUserDouble("Enter recoil value: ");
    int magSize = getUserInt("Enter magazine size: ");
    // Add prompts for heat/cooling if needed

    return std::make_unique<Firearm>(name, weight, range, caliber, fireRate, recoil, magSize);
}

std::unique_ptr<Weapon> CLIHandler::createExplosive() {
    std::cout << "\n-- Designing Explosive --" << std::endl;
    std::string name = getUserString("Enter weapon name: ");
    double weight = getUserDouble("Enter weight (kg): ");
    double range = getUserDouble("Enter effective range/throw distance (m): ");
    std::string payload = getUserString("Enter payload type (e.g., HE, Frag): ");
    double radius = getUserDouble("Enter blast radius (m): ");
    double damage = getUserDouble("Enter damage at center: ");
    double fuse = getUserDouble("Enter fuse time (s, 0 for impact): ");
    
    std::cout << "Select delivery method: 1. Thrown, 2. Launched, 3. Placed: ";
    int methodChoice = getUserChoice(1, 3);
    ExplosiveDeliveryMethod method = ExplosiveDeliveryMethod::THROWN;
    if (methodChoice == 2) method = ExplosiveDeliveryMethod::LAUNCHED;
    if (methodChoice == 3) method = ExplosiveDeliveryMethod::PLACED;

    return std::make_unique<Explosive>(name, weight, range, payload, radius, damage, method, fuse);
}

std::unique_ptr<Weapon> CLIHandler::createMissile() {
    std::cout << "\n-- Designing Missile --" << std::endl;
    std::string name = getUserString("Enter missile name: ");
    double weight = getUserDouble("Enter weight (kg): ");
    double range = getUserDouble("Enter max range (m): ");
    
    std::cout << "Select guidance system: 1. Unguided, 2. IR, 3. Radar, 4. Laser, 5. GPS: ";
    int guidanceChoice = getUserChoice(1, 5);
    MissileGuidanceSystem guidance = MissileGuidanceSystem::UNGUIDED;
    switch(guidanceChoice) {
        case 2: guidance = MissileGuidanceSystem::INFRARED; break;
        case 3: guidance = MissileGuidanceSystem::RADAR; break;
        case 4: guidance = MissileGuidanceSystem::LASER; break;
        case 5: guidance = MissileGuidanceSystem::GPS; break;
    }

    double speed = getUserDouble("Enter max speed (m/s): ");
    double fuel = getUserDouble("Enter fuel capacity: ");
    double turnRate = getUserDouble("Enter turn rate (deg/s): ");

    std::cout << "\n-- Designing Missile Payload (Explosive) --" << std::endl;
    std::string payloadName = getUserString("Enter payload name: ");
    std::string payloadType = getUserString("Enter payload type (e.g., HE, Frag): ");
    double payloadRadius = getUserDouble("Enter payload blast radius (m): ");
    double payloadDamage = getUserDouble("Enter payload damage at center: ");
    // Payload is typically launched/part of missile, range/fuse/weight might be less relevant here
    auto payload = std::make_unique<Explosive>(payloadName, 0, 0, payloadType, payloadRadius, payloadDamage, ExplosiveDeliveryMethod::LAUNCHED, 0.0);

    return std::make_unique<Missile>(name, weight, range, guidance, speed, fuel, turnRate, std::move(payload));
}

std::unique_ptr<Weapon> CLIHandler::createLaserWeapon() {
    std::cout << "\n-- Designing Laser Weapon --" << std::endl;
    std::string name = getUserString("Enter weapon name: ");
    double weight = getUserDouble("Enter weight (kg): ");
    double range = getUserDouble("Enter effective range (m): ");
    double power = getUserDouble("Enter power output (kW): ");
    double duration = getUserDouble("Enter beam duration/pulse (s): ");
    double energyCost = getUserDouble("Enter energy cost per shot/pulse (J): ");
    double heatGen = getUserDouble("Enter heat generated per shot/pulse: ");
    double maxHeat = getUserDouble("Enter max heat capacity: ");
    double coolRate = getUserDouble("Enter cooling rate (/s): ");
    double energyCap = getUserDouble("Enter energy source capacity (J): ");

    return std::make_unique<LaserWeapon>(name, weight, range, power, duration, energyCost, heatGen, maxHeat, coolRate, energyCap);
}

// --- Menu Action Implementations ---

void CLIHandler::handleWeaponDesign() {
    // Implementation moved inside the function above for clarity
    // This function now just calls the creation logic
    handleWeaponDesign(); // This seems recursive, fixing it.
    // Corrected version:
    // The logic is already within the processMainMenuChoice calling this, 
    // and the actual creation happens in the helper functions called within.
    // So this function body can be simplified or the logic refactored.
    // Let's keep the creation logic within handleWeaponDesign for now.
    std::cout << "\n--- Design New Weapon ---" << std::endl;
    std::cout << "Select weapon type:" << std::endl;
    std::cout << "1. Firearm" << std::endl;
    std::cout << "2. Explosive" << std::endl;
    std::cout << "3. Missile" << std::endl;
    std::cout << "4. Laser Weapon" << std::endl;
    std::cout << "5. Cancel" << std::endl;
    int choice = getUserChoice(1, 5);

    std::unique_ptr<Weapon> newWeapon = nullptr;
    switch (choice) {
        case 1: newWeapon = createFirearm(); break;
        case 2: newWeapon = createExplosive(); break;
        case 3: newWeapon = createMissile(); break;
        case 4: newWeapon = createLaserWeapon(); break;
        case 5: std::cout << "Design cancelled." << std::endl; return;
    }

    if (newWeapon) {
        std::cout << "Weapon \"" << newWeapon->getName() << "\" designed successfully." << std::endl;
        // TODO: Add attachment logic here if desired
        designedWeapons.push_back(std::move(newWeapon));
    } else {
        // Error message handled in creation functions if needed
        std::cerr << "Weapon creation failed or was cancelled." << std::endl;
    }
}

void CLIHandler::handleViewWeapons() const {
    // Implementation moved inside the function above for clarity
    // Corrected version:
    std::cout << "\n--- Designed Weapons ---" << std::endl;
    if (designedWeapons.empty()) {
        std::cout << "No weapons designed yet." << std::endl;
        return;
    }
    for (size_t i = 0; i < designedWeapons.size(); ++i) {
        std::cout << "\n--- Weapon #" << (i + 1) << " ---" << std::endl;
        if (designedWeapons[i]) {
             designedWeapons[i]->displayStats();
        } else {
             std::cout << "Error: Invalid weapon pointer." << std::endl;
        }
    }
}

void CLIHandler::handleConfigureEnvironment() {
    // Implementation moved inside the function above for clarity
    // Corrected version:
    std::cout << "\n--- Configure Environment ---" << std::endl;
    std::cout << "Current Gravity: " << currentEnvironment.gravity << " m/s^2" << std::endl;
    currentEnvironment.gravity = getUserDouble("Enter new gravity (e.g., 9.81): ");
    std::cout << "Current Air Density: " << currentEnvironment.airDensity << " kg/m^3" << std::endl;
    currentEnvironment.airDensity = getUserDouble("Enter new air density (e.g., 1.225): ");
    // Add wind configuration later
    // currentEnvironment.wind.x = getUserDouble("Enter wind X component (m/s): ");
    // currentEnvironment.wind.y = getUserDouble("Enter wind Y component (m/s): ");
    // currentEnvironment.wind.z = getUserDouble("Enter wind Z component (m/s): ");
    std::cout << "Environment updated." << std::endl;
}

void CLIHandler::handleConfigureTarget() {
    // Implementation moved inside the function above for clarity
    // Corrected version:
    std::cout << "\n--- Configure Target ---" << std::endl;
    std::cout << "Current Target Position: (" << currentTarget.position.x << ", " << currentTarget.position.y << ", " << currentTarget.position.z << ")" << std::endl;
    currentTarget.position.x = getUserDouble("Enter target X coordinate: ");
    currentTarget.position.y = getUserDouble("Enter target Y coordinate: ");
    currentTarget.position.z = getUserDouble("Enter target Z coordinate: ");
    std::cout << "Current Target Health: " << currentTarget.health << std::endl;
    currentTarget.health = getUserDouble("Enter new target health: ");
    // Add material configuration later
    // currentTarget.material.name = getUserString("Enter target material name: ");
    // currentTarget.material.hardness = getUserDouble("Enter material hardness: ");
    std::cout << "Target updated." << std::endl;
}

void CLIHandler::handleRunSimulation() {
    // Implementation moved inside the function above for clarity
    // Corrected version:
    std::cout << "\n--- Run Simulation ---" << std::endl;
    if (designedWeapons.empty()) {
        std::cout << "No weapons designed yet. Please design a weapon first." << std::endl;
        return;
    }

    std::cout << "Select weapon to simulate:" << std::endl;
    for (size_t i = 0; i < designedWeapons.size(); ++i) {
        std::cout << (i + 1) << ". " << designedWeapons[i]->getName() << std::endl;
    }
    int choice = getUserChoice(1, designedWeapons.size());
    Weapon* selectedWeapon = designedWeapons[choice - 1].get();

    // Create a temporary copy of the target for this simulation run
    Target simTarget = currentTarget; 
    // Optionally reset health for each run
    // simTarget.health = 100.0; // Or get from config

    std::cout << "\nSimulating with weapon: " << selectedWeapon->getName() << std::endl;
    std::cout << "Target at: (" << simTarget.position.x << ", " << simTarget.position.y << ", " << simTarget.position.z << ") with " << simTarget.health << " HP" << std::endl;
    std::cout << "Environment: Gravity=" << currentEnvironment.gravity << ", AirDensity=" << currentEnvironment.airDensity << std::endl;
    
    // --- Run the simulation using the engine --- 
    // The current SimulationEngine::runSimulation is basic. 
    // A more complete version would likely involve multiple shots or a time loop.
    // For now, we just call the weapon's fire method directly as a placeholder
    // until SimulationEngine is fully implemented.
    
    // SimulationResult result = simEngine->runSimulation(*selectedWeapon, simTarget, currentEnvironment);
    SimulationResult result = selectedWeapon->fire(simTarget, currentEnvironment);

    std::cout << "\n--- Simulation Result ---" << std::endl;
    std::cout << "Outcome: " << result.message << std::endl;
    if (result.hit) {
        std::cout << "Impact Point: (" << result.impactPoint.x << ", " << result.impactPoint.y << ", " << result.impactPoint.z << ")" << std::endl;
        std::cout << "Time of Flight: " << result.timeOfFlight << " s" << std::endl;
        
        // Calculate and display damage
        DamageReport damage = selectedWeapon->simulateImpact(result.impactPoint, simTarget);
        std::cout << "Damage Dealt: " << damage.damageDealt << std::endl;
        std::cout << "Impact Effect: " << damage.effectDescription << std::endl;
        
        // Update target health (if needed for multi-shot sims later)
        // simTarget.health -= damage.damageDealt;
        // std::cout << "Target Remaining Health: " << simTarget.health << std::endl;
    }
    std::cout << "-------------------------" << std::endl;
    
    // Display weapon status after firing (ammo, heat, etc.)
    selectedWeapon->displayStats();
    
    // Ask if user wants to reload
    if (dynamic_cast<Firearm*>(selectedWeapon)) { // Only offer reload for firearms for now
         char reloadChoice = 'n';
         std::cout << "Reload weapon? (y/n): ";
         std::cin >> reloadChoice;
         std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); 
         if (reloadChoice == 'y' || reloadChoice == 'Y') {
             selectedWeapon->reload();
             std::cout << "Weapon reloaded." << std::endl;
         }
    }
}

void CLIHandler::handleCompareWeapons() const {
    std::cout << "\n--- Compare Weapons (Placeholder) ---" << std::endl;
    std::cout << "Comparison feature not yet implemented." << std::endl;
    // TODO: Implement comparison logic (e.g., side-by-side stats)
}

