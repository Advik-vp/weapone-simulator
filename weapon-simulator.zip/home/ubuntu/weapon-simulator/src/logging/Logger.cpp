#include "logging/Logger.h"
#include "weapons/Firearm.h"
#include "weapons/Explosive.h"
#include "weapons/Missile.h"
#include "weapons/LaserWeapon.h"
#include <fstream>
#include <iostream> // For cerr
#include <iomanip> // For put_time, setprecision
#include <sstream> // For stringstream
#include <chrono>
#include <ctime>
#include <stdexcept> // For runtime_error
#include <string> // For std::string manipulation

// Helper function to escape quotes for CSV
std::string escapeCsvString(const std::string& s) {
    std::string escaped = s;
    size_t pos = 0;
    while ((pos = escaped.find('"', pos)) != std::string::npos) {
        escaped.replace(pos, 1, """"); // Replace " with ""
        pos += 2; // Move past the inserted quote
    }
    return escaped;
}

// Helper function to escape quotes and special characters for JSON
std::string escapeJsonString(const std::string& s) {
    std::string escaped;
    escaped.reserve(s.length()); // Reserve space to avoid reallocations
    for (char c : s) {
        switch (c) {
            case '"':  escaped += "\\\""; break;
            case '\\': escaped += "\\\\"; break;
            case '\b': escaped += "\\b"; break;
            case '\f': escaped += "\\f"; break;
            case '\n': escaped += "\\n"; break;
            case '\r': escaped += "\\r"; break;
            case '\t': escaped += "\\t"; break;
            default:
                // Check if character is control character (0-31)
                if (c >= 0 && c <= 31) {
                    // Represent as \uXXXX hex code
                    char buf[7];
                    snprintf(buf, sizeof(buf), "\\u%04X", static_cast<unsigned int>(c));
                    escaped += buf;
                } else {
                    escaped += c;
                }
                break;
        }
    }
    return escaped;
}


// Helper to get current timestamp as string
std::string Logger::getTimestamp() const {
    auto now = std::chrono::system_clock::now();
    auto now_c = std::chrono::system_clock::to_time_t(now);
    std::stringstream ss;
    // Using std::put_time, requires #include <iomanip>
    #ifdef __GNUC__
    #if __GNUC__ < 5
        char buf[30];
        strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", std::localtime(&now_c));
        ss << buf;
    #else
        ss << std::put_time(std::localtime(&now_c), "%Y-%m-%d %H:%M:%S");
    #endif
    #else // Assume MSVC or Clang which support put_time
         ss << std::put_time(std::localtime(&now_c), "%Y-%m-%d %H:%M:%S");
    #endif
    return ss.str();
}

// Helper to get weapon type as string
std::string Logger::getWeaponType(const Weapon* weapon) const {
    if (!weapon) return "Unknown";
    if (dynamic_cast<const Firearm*>(weapon)) return "Firearm";
    if (dynamic_cast<const Explosive*>(weapon)) return "Explosive";
    if (dynamic_cast<const Missile*>(weapon)) return "Missile";
    if (dynamic_cast<const LaserWeapon*>(weapon)) return "LaserWeapon";
    return "BaseWeapon"; // Should not happen with proper derived classes
}

// Log a simulation event
void Logger::logSimulation(const Weapon& weapon, const Target& initialTargetState, const Environment& env, const SimulationResult& result, const DamageReport& damage, double finalTargetHealth) {
    SimulationRecord record;
    record.timestamp = getTimestamp();
    record.weaponName = weapon.getName();
    record.weaponType = getWeaponType(&weapon);
    // TODO: Add specific weapon parameters based on type if needed
    record.targetInitialHealth = initialTargetState.health;
    record.targetPosition = initialTargetState.position; // Log initial position
    // TODO: Log relevant environment details (e.g., env.gravity, env.wind.x etc.)
    record.result = result;
    record.damage = damage;
    record.targetFinalHealth = finalTargetHealth;

    records.push_back(record);
}

// Save logs to CSV file
bool Logger::saveReportCSV(const std::string& filename) const {
    std::ofstream outFile(filename);
    if (!outFile.is_open()) {
        std::cerr << "Error: Could not open file for CSV report: " << filename << std::endl;
        return false;
    }

    // Write header
    outFile << "Timestamp,WeaponName,WeaponType,TargetInitialHealth,TargetPosX,TargetPosY,TargetPosZ,Hit,ImpactX,ImpactY,ImpactZ,TimeOfFlight,FinalVelocity,ResultMessage,DamageDealt,Penetration,BlastRadiusAffected,HeatTransferred,DamageEffect,TargetDestroyed,TargetFinalHealth\n";

    // Write records
    outFile << std::fixed << std::setprecision(3); // Set precision for floating point numbers
    for (const auto& record : records) {
        // Correctly quote string fields for CSV, escaping internal quotes
        outFile << "\"" << escapeCsvString(record.timestamp) << "\",";
        outFile << "\"" << escapeCsvString(record.weaponName) << "\",";
        outFile << "\"" << escapeCsvString(record.weaponType) << "\",";
        outFile << record.targetInitialHealth << ",";
        outFile << record.targetPosition.x << "," << record.targetPosition.y << "," << record.targetPosition.z << ",";
        outFile << (record.result.hit ? "Yes" : "No") << ",";
        outFile << record.result.impactPoint.x << "," << record.result.impactPoint.y << "," << record.result.impactPoint.z << ",";
        outFile << record.result.timeOfFlight << ",";
        outFile << record.result.finalVelocity << ",";
        outFile << "\"" << escapeCsvString(record.result.message) << "\",";
        outFile << record.damage.damageDealt << ",";
        outFile << record.damage.penetrationDepth << ",";
        outFile << record.damage.blastRadiusAffected << ",";
        outFile << record.damage.heatTransferred << ",";
        outFile << "\"" << escapeCsvString(record.damage.effectDescription) << "\",";
        outFile << (record.damage.targetDestroyed ? "Yes" : "No") << ",";
        outFile << record.targetFinalHealth << "\n";
    }

    outFile.close();
    std::cout << "CSV report saved to: " << filename << std::endl;
    return true;
}

// Save logs to JSON file (basic implementation)
bool Logger::saveReportJSON(const std::string& filename) const {
    std::ofstream outFile(filename);
    if (!outFile.is_open()) {
        std::cerr << "Error: Could not open file for JSON report: " << filename << std::endl;
        return false;
    }

    outFile << "{\n";
    outFile << "  \"simulation_logs\": [\n";
    outFile << std::fixed << std::setprecision(3);

    for (size_t i = 0; i < records.size(); ++i) {
        const auto& record = records[i];
        outFile << "    {\n";
        // Correctly format JSON strings, escaping necessary characters
        outFile << "      \"timestamp\": \"" << escapeJsonString(record.timestamp) << "\",\n";
        outFile << "      \"weapon_name\": \"" << escapeJsonString(record.weaponName) << "\",\n";
        outFile << "      \"weapon_type\": \"" << escapeJsonString(record.weaponType) << "\",\n";
        outFile << "      \"target_initial_health\": " << record.targetInitialHealth << ",\n";
        outFile << "      \"target_position\": { \"x\": " << record.targetPosition.x << ", \"y\": " << record.targetPosition.y << ", \"z\": " << record.targetPosition.z << " },\n";
        outFile << "      \"simulation_result\": {\n";
        outFile << "        \"hit\": " << (record.result.hit ? "true" : "false") << ",\n";
        outFile << "        \"impact_point\": { \"x\": " << record.result.impactPoint.x << ", \"y\": " << record.result.impactPoint.y << ", \"z\": " << record.result.impactPoint.z << " },\n";
        outFile << "        \"time_of_flight\": " << record.result.timeOfFlight << ",\n";
        outFile << "        \"final_velocity\": " << record.result.finalVelocity << ",\n";
        outFile << "        \"message\": \"" << escapeJsonString(record.result.message) << "\"\n";
        outFile << "      },\n";
        outFile << "      \"damage_report\": {\n";
        outFile << "        \"damage_dealt\": " << record.damage.damageDealt << ",\n";
        outFile << "        \"penetration_depth\": " << record.damage.penetrationDepth << ",\n";
        outFile << "        \"blast_radius_affected\": " << record.damage.blastRadiusAffected << ",\n";
        outFile << "        \"heat_transferred\": " << record.damage.heatTransferred << ",\n";
        outFile << "        \"effect_description\": \"" << escapeJsonString(record.damage.effectDescription) << "\",\n";
        outFile << "        \"target_destroyed\": " << (record.damage.targetDestroyed ? "true" : "false") << "\n";
        outFile << "      },\n";
        outFile << "      \"target_final_health\": " << record.targetFinalHealth << "\n";
        outFile << "    }";
        if (i < records.size() - 1) {
            outFile << ",";
        }
        outFile << "\n";
    }

    outFile << "  ]\n";
    outFile << "}\n";

    outFile.close();
    std::cout << "JSON report saved to: " << filename << std::endl;
    return true;
}

// Clear all logged records
void Logger::clearLogs() {
    records.clear();
    std::cout << "Simulation logs cleared." << std::endl;
}

// Get the number of records logged
size_t Logger::getRecordCount() const {
    return records.size();
}

