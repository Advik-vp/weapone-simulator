#ifndef EXPLOSIVE_H
#define EXPLOSIVE_H

#include "core/Weapon.h"
#include <string>
#include <memory> // For unique_ptr

// Forward declarations
struct SimulationResult;
struct DamageReport;
struct Target;
struct Environment;

// Enum for how the explosive is delivered
enum class ExplosiveDeliveryMethod {
    THROWN,
    LAUNCHED,
    PLACED
};

class Explosive : public Weapon {
private:
    std::string payloadType;
    double blastRadius; // meters
    double maxDamage; // Damage at epicenter
    ExplosiveDeliveryMethod deliveryMethod;
    double fuseTimer; // Seconds (0 for impact fuse)
    bool isArmed;

public:
    // Constructor
    Explosive(const std::string& name, double weight, double range, 
              const std::string& type, double radius, double dmg, 
              ExplosiveDeliveryMethod method, double fuseTime);

    // Copy Constructor (Deep Copy for Attachments)
    Explosive(const Explosive& other);

    // Destructor
    ~Explosive() override = default;

    // Inherited pure virtual functions
    SimulationResult fire(const Target& target, const Environment& env) override;
    void reload() override;
    DamageReport simulateImpact(const Vector3D& impactPoint, const Target& target) override;
    void displayStats() const override;
    std::unique_ptr<Weapon> clone() const override;

    // Explosive specific methods
    void arm(); // Method to arm the explosive (used by Missile)
    const std::string& getPayloadType() const;
    double getBlastRadius() const;
    double getMaxDamage() const;
};

#endif // EXPLOSIVE_H
