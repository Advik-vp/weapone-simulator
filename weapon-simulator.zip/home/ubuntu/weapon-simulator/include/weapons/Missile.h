#ifndef MISSILE_H
#define MISSILE_H

#include "core/Weapon.h"
#include "weapons/Explosive.h" // Include Explosive for payload
#include <string>
#include <memory> // For unique_ptr

// Forward declarations
struct SimulationResult;
struct DamageReport;
struct Target;
struct Environment;

// Enum for guidance systems
enum class MissileGuidanceSystem {
    UNGUIDED,
    INFRARED,
    RADAR,
    LASER,
    GPS
};

class Missile : public Weapon {
private:
    MissileGuidanceSystem guidanceSystem;
    double maxSpeed; // m/s
    double fuelCapacity;
    double currentFuel;
    double turnRate; // degrees per second
    std::unique_ptr<Explosive> payload; // Missile carries an explosive payload
    bool isLaunched;
    bool targetLocked;
    Vector3D position; // Current position (needed for more complex simulation)

public:
    // Constructor
    Missile(const std::string& name, double weight, double range,
            MissileGuidanceSystem guide, double spd, double fuelCap, double turn,
            std::unique_ptr<Explosive> warhead);

    // Copy Constructor (Deep Copy for Attachments and Payload)
    Missile(const Missile& other);

    // Destructor
    ~Missile() override = default;

    // Inherited pure virtual functions
    SimulationResult fire(const Target& target, const Environment& env) override;
    void reload() override;
    DamageReport simulateImpact(const Vector3D& impactPoint, const Target& target) override;
    void displayStats() const override;
    std::unique_ptr<Weapon> clone() const override;

    // Missile specific methods (if any)
    // ... Getters for missile specific properties ...

};

#endif // MISSILE_H
