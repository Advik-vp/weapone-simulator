#ifndef FIREARM_H
#define FIREARM_H

#include "core/Weapon.h"
#include <string>
#include <vector>
#include <memory> // For unique_ptr

// Forward declarations if needed
struct SimulationResult;
struct DamageReport;
struct Target;
struct Environment;

class Firearm : public Weapon {
private:
    double caliber; // mm
    double fireRate; // Rounds per minute
    double recoil; // Abstract recoil value
    int magazineCapacity;
    int currentAmmo;
    double barrelHeat;
    double coolingRate; // Heat units per second
    // SimulationResult result; // Store last fire result? Maybe not needed here.

public:
    // Constructor
    Firearm(const std::string& name, double weight, double range, 
            double cal, double rate, double rec, int magSize);

    // Copy Constructor (Deep Copy for Attachments)
    Firearm(const Firearm& other);

    // Destructor
    ~Firearm() override = default;

    // Inherited pure virtual functions
    SimulationResult fire(const Target& target, const Environment& env) override;
    void reload() override;
    DamageReport simulateImpact(const Vector3D& impactPoint, const Target& target) override;
    void displayStats() const override;
    std::unique_ptr<Weapon> clone() const override;

    // Firearm specific methods
    int getMagazineCapacity() const; // Declaration added
    void setMagazineCapacity(int capacity); // Declaration added
    int getCurrentAmmo() const { return currentAmmo; }
    double getBarrelHeat() const { return barrelHeat; }
    // Add other getters/setters as needed
};

#endif // FIREARM_H
