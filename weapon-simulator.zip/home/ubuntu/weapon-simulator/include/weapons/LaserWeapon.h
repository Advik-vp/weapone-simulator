#ifndef LASER_WEAPON_H
#define LASER_WEAPON_H

#include "core/Weapon.h"
#include <string>
#include <memory> // For unique_ptr

// Forward declarations
struct SimulationResult;
struct DamageReport;
struct Target;
struct Environment;

class LaserWeapon : public Weapon {
private:
    double powerOutput; // kW
    double beamDuration; // seconds
    double energyPerShot; // Joules
    double heatGeneratedPerShot;
    double maxHeatCapacity;
    double coolingRatePerSecond;
    double energySourceCapacity; // Joules
    double currentEnergy;
    double currentHeat;

public:
    // Constructor
    LaserWeapon(const std::string& name, double weight, double range,
                double power, double duration, double energyCostPerShot,
                double heatGen, double maxHeatCap, double coolRate, double energyCap);

    // Copy Constructor (Deep Copy for Attachments)
    LaserWeapon(const LaserWeapon& other);

    // Destructor
    ~LaserWeapon() override = default;

    // Inherited pure virtual functions
    SimulationResult fire(const Target& target, const Environment& env) override;
    void reload() override; // Represents recharging
    DamageReport simulateImpact(const Vector3D& impactPoint, const Target& target) override;
    void displayStats() const override;
    std::unique_ptr<Weapon> clone() const override;

    // Laser specific methods (if any)
    // ... Getters for laser specific properties ...
};

#endif // LASER_WEAPON_H
