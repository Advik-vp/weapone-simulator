#ifndef LOGGER_H
#define LOGGER_H

#include "simulation/SimulationCommon.h"
#include "core/Weapon.h"
#include "core/Target.h"
#include "core/Environment.h"
#include <vector>
#include <string>
#include <fstream>
#include <chrono>
#include <ctime>
#include <iomanip> // For std::put_time

// Structure to hold a complete simulation record
struct SimulationRecord {
    std::string timestamp;
    std::string weaponName;
    std::string weaponType;
    // Add key weapon parameters (e.g., caliber for firearm, power for laser)
    double targetInitialHealth;
    Vector3D targetPosition;
    // Environment details (e.g., gravity, wind)
    SimulationResult result;
    DamageReport damage;
    double targetFinalHealth;
};

class Logger {
private:
    std::vector<SimulationRecord> records;
    std::string getTimestamp() const;
    std::string getWeaponType(const Weapon* weapon) const;

public:
    Logger() = default;

    void logSimulation(const Weapon& weapon, const Target& initialTargetState, const Environment& env, const SimulationResult& result, const DamageReport& damage, double finalTargetHealth);

    bool saveReportCSV(const std::string& filename) const;
    bool saveReportJSON(const std::string& filename) const;

    void clearLogs();
    size_t getRecordCount() const;
};

#endif // LOGGER_H
