#ifndef SILENCER_H
#define SILENCER_H

#include "core/Attachment.h"
#include "core/Weapon.h" // Include Weapon for applyEffect
#include <iostream> // For std::cout
#include <memory> // For std::unique_ptr

class Silencer : public Attachment {
private:
    double noiseReductionFactor; // e.g., 0.5 for 50% reduction
    double rangePenaltyFactor;   // e.g., 0.9 for 10% range reduction

public:
    Silencer(double noiseReduction = 0.7, double rangePenalty = 0.95)
        : noiseReductionFactor(noiseReduction), rangePenaltyFactor(rangePenalty) {}

    void applyEffect(Weapon& weapon) override {
        // Placeholder: Modify weapon stats like noise level, range
        std::cout << "Silencer attached: Noise reduced by " << (1.0 - noiseReductionFactor) * 100 << "%, Range reduced by " << (1.0 - rangePenaltyFactor) * 100 << "%." << std::endl;
        // Example: weapon.setEffectiveRange(weapon.getEffectiveRange() * rangePenaltyFactor);
        // Example: weapon.setNoiseLevel(weapon.getNoiseLevel() * noiseReductionFactor); // Assuming Weapon has noise level
    }

    std::string getName() const override {
        return "Silencer";
    }

    // Implement the clone method for deep copying
    std::unique_ptr<Attachment> clone() const override {
        return std::make_unique<Silencer>(*this);
    }
};

#endif // SILENCER_H
