#ifndef EXTENDED_MAGAZINE_H
#define EXTENDED_MAGAZINE_H

#include "core/Attachment.h"
#include "weapons/Firearm.h" // Include Firearm to modify its properties
#include <iostream> // For std::cout
#include <memory> // For std::unique_ptr

class ExtendedMagazine : public Attachment {
private:
    int additionalCapacity;

public:
    ExtendedMagazine(int capacityIncrease = 10) : additionalCapacity(capacityIncrease) {}

    void applyEffect(Weapon& weapon) override {
        // Try to cast the weapon to a Firearm
        if (Firearm* firearm = dynamic_cast<Firearm*>(&weapon)) {
            int oldCapacity = firearm->getMagazineCapacity();
            firearm->setMagazineCapacity(oldCapacity + additionalCapacity);
            std::cout << "Extended Magazine attached: Capacity increased by " << additionalCapacity
                      << " (New capacity: " << firearm->getMagazineCapacity() << ")." << std::endl;
        } else {
            std::cout << "Extended Magazine can only be attached to Firearms." << std::endl;
            // Optionally throw an exception or handle the error appropriately
        }
    }

    std::string getName() const override {
        return "Extended Magazine (+" + std::to_string(additionalCapacity) + ")";
    }

    // Implement the clone method for deep copying
    std::unique_ptr<Attachment> clone() const override {
        return std::make_unique<ExtendedMagazine>(*this);
    }
};

#endif // EXTENDED_MAGAZINE_H
