#ifndef SCOPE_H
#define SCOPE_H

#include "core/Attachment.h"
#include "core/Weapon.h" // Include Weapon for applyEffect
#include <iostream> // For std::cout
#include <memory> // For std::unique_ptr

class Scope : public Attachment {
private:
    double zoomLevel;
    bool nightVision;

public:
    Scope(double zoom = 4.0, bool nv = false) : zoomLevel(zoom), nightVision(nv) {}

    void applyEffect(Weapon& weapon) override {
        // Placeholder: In a real sim, this might modify accuracy or range stats
        std::cout << "Scope attached: " << zoomLevel << "x zoom" << (nightVision ? " with NV." : ".") << std::endl;
        // Example: weapon.setEffectiveRange(weapon.getEffectiveRange() * (1 + zoomLevel / 10.0)); // Increase range slightly
    }

    std::string getName() const override {
        return "Scope (" + std::to_string(static_cast<int>(zoomLevel)) + "x" + (nightVision ? " NV" : "") + ")";
    }

    // Implement the clone method for deep copying
    std::unique_ptr<Attachment> clone() const override {
        return std::make_unique<Scope>(*this);
    }
};

#endif // SCOPE_H
