#ifndef SIMULATION_COMMON_H
#define SIMULATION_COMMON_H

#include "core/Vector3D.h"
#include <vector>
#include <string>

// Result of a single weapon fire action
struct SimulationResult {
    bool hit = false;
    Vector3D impactPoint;
    double timeOfFlight = 0.0;
    double finalVelocity = 0.0; // Velocity at impact
    std::string message = ""; // e.g., "Miss", "Hit", "Target Destroyed", "Misfire"
    // Potentially add trajectory path points for visualization
    // std::vector<Vector3D> trajectoryPath;
};

// Report detailing the effects of an impact
struct DamageReport {
    double damageDealt = 0.0;
    double penetrationDepth = 0.0; // For kinetic impacts
    double blastRadiusAffected = 0.0; // For explosives
    double heatTransferred = 0.0; // For lasers
    std::string effectDescription = ""; // e.g., "Armor Pierced", "Target Incapacitated"
    bool targetDestroyed = false;
};

#endif // SIMULATION_COMMON_H
