#ifndef SIMULATION_ENGINE_H
#define SIMULATION_ENGINE_H

#include "core/Weapon.h"
#include "core/Target.h"
#include "core/Environment.h"
#include "simulation/SimulationCommon.h"
#include <memory> // For unique_ptr

// Forward declarations for weapon types to avoid circular includes if possible
// However, since we need the actual types for dynamic_cast and method calls,
// including the headers is often necessary here or in the .cpp file.
class Firearm;
class Explosive;
class Missile;
class LaserWeapon;

// Forward declarations for strategy interfaces (if used)
class ITrajectoryCalculator;
class IImpactCalculator;

class SimulationEngine {
private:
    // Potential strategy pattern members
    // std::unique_ptr<ITrajectoryCalculator> trajectoryStrategy;
    // std::unique_ptr<IImpactCalculator> impactStrategy;

    // Helper methods for different weapon types (or use strategy)
    // Ensure pointer types match the actual weapon classes
    SimulationResult simulateFirearmShot(Firearm* firearm, const Target& target, const Environment& env);
    SimulationResult simulateExplosiveLaunch(Explosive* explosive, const Target& target, const Environment& env);
    SimulationResult simulateMissileLaunch(Missile* missile, const Target& target, const Environment& env); // Corrected pointer type
    SimulationResult simulateLaserFire(LaserWeapon* laser, const Target& target, const Environment& env); // Corrected pointer type

    // Common physics calculations (could be moved to a separate PhysicsUtil class)
    // Ensure signature matches the implementation file
    Vector3D calculateBallisticTrajectory(const Vector3D& startPos, const Vector3D& initialVelocity, double mass, double dragCoefficient, double crossSectionalArea, const Environment& env, double timeStep, double maxTime, Vector3D& impactPoint, double& timeOfFlight);
    bool checkCollision(const Vector3D& projectilePos, const Target& target);

public:
    SimulationEngine();
    ~SimulationEngine();

    // The main simulation function
    SimulationResult runSimulation(Weapon& weapon, Target& target, const Environment& env);

};

#endif // SIMULATION_ENGINE_H
