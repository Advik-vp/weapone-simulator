#ifndef WEAPON_H
#define WEAPON_H

#include <string>
#include <vector>
#include <memory>
#include "Vector3D.h"
#include "core/Attachment.h" // Include the full definition for Attachment

// Forward declarations for types used only as pointers/references in this header
struct Target;
struct Environment;
struct SimulationResult;
struct DamageReport;

class Weapon {
protected:
    std::string name;
    double weight; // in kg
    double effectiveRange; // in meters
    // Use unique_ptr for ownership semantics
    std::vector<std::unique_ptr<Attachment>> attachments;

public:
    // Constructor
    Weapon(std::string name, double weight, double range)
        : name(std::move(name)), weight(weight), effectiveRange(range) {}

    // Virtual destructor is crucial for base classes with virtual functions
    virtual ~Weapon() = default;

    // Pure virtual functions to be implemented by derived classes
    virtual SimulationResult fire(const Target& target, const Environment& env) = 0;
    virtual void reload() = 0;
    virtual DamageReport simulateImpact(const Vector3D& impactPoint, const Target& target) = 0;
    virtual void displayStats() const = 0;
    virtual std::unique_ptr<Weapon> clone() const = 0; // For Prototype pattern

    // Common methods
    const std::string& getName() const { return name; }
    double getWeight() const { return weight; }
    double getEffectiveRange() const { return effectiveRange; }

    // Attachment management
    virtual void addAttachment(std::unique_ptr<Attachment> attachment);
    // Note: Removing attachments might be complex (e.g., by name or type), simplified for now.
    // virtual void removeAttachment(const std::string& attachmentName);

    // Allow modification during design phase (optional, could use builder pattern)
    void setName(const std::string& newName) { name = newName; }
    void setWeight(double newWeight) { weight = newWeight; }
    void setEffectiveRange(double newRange) { effectiveRange = newRange; }
};

// Placeholder definitions for structs/classes defined elsewhere but needed for compilation
// These should be included where they are fully defined, not here.
// struct Target { Vector3D position; /* ... */ }; // Defined in core/Target.h
// struct Environment { Vector3D wind; double gravity = 9.81; /* ... */ }; // Defined in core/Environment.h
// struct SimulationResult { bool hit = false; Vector3D impactPoint; double timeOfFlight = 0.0; /* ... */ }; // Defined in simulation/SimulationCommon.h
// struct DamageReport { double damageDealt = 0.0; /* ... */ }; // Defined in simulation/SimulationCommon.h

#endif // WEAPON_H
