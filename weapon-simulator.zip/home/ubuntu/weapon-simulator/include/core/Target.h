#ifndef TARGET_H
#define TARGET_H

#include "core/Vector3D.h"
#include <string>

// Basic material properties - can be expanded later
struct MaterialProperties {
    std::string name = "Generic";
    double density = 1.0; // kg/m^3
    double hardness = 1.0; // Arbitrary scale
    // Add more properties like thermal conductivity, armor rating, etc.
};

struct Target {
    Vector3D position;
    // Changed size from Vector3D to double representing radius for simple collision
    double radius = 0.5; // Default radius (e.g., 0.5 meters for a 1m diameter sphere)
    MaterialProperties material;
    double health = 100.0;
    bool isMobile = false; // Future use for moving targets
    Vector3D velocity = {0.0, 0.0, 0.0}; // Future use

    // Updated constructor to potentially accept radius
    Target(Vector3D pos = {}, double hp = 100.0, MaterialProperties mat = {}, double rad = 0.5)
        : position(pos), radius(rad), health(hp), material(mat) {}
};

#endif // TARGET_H
