#ifndef ATTACHMENT_H
#define ATTACHMENT_H

#include <string>
#include <memory> // For std::unique_ptr

// Forward declaration
class Weapon;

class Attachment {
public:
    virtual ~Attachment() = default;
    virtual void applyEffect(Weapon& weapon) = 0; // Apply the attachment's effect
    virtual std::string getName() const = 0;
    virtual std::unique_ptr<Attachment> clone() const = 0; // Add clone method for deep copying
};

#endif // ATTACHMENT_H
