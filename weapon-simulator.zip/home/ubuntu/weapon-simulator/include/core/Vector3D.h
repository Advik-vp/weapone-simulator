#ifndef VECTOR3D_H
#define VECTOR3D_H

#include <cmath> // Required for sqrt, pow
#include <limits> // Required for numeric_limits

struct Vector3D {
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;

    // Basic constructor
    Vector3D(double x_ = 0.0, double y_ = 0.0, double z_ = 0.0) : x(x_), y(y_), z(z_) {}

    // Calculate the magnitude (length) of the vector
    double magnitude() const {
        return std::sqrt(x * x + y * y + z * z);
    }

    // Calculate the squared magnitude (avoids sqrt for comparisons)
    double magnitudeSquared() const {
        return x * x + y * y + z * z;
    }

    // Return a normalized version of the vector (unit vector)
    Vector3D normalized() const {
        double mag = magnitude();
        if (mag > std::numeric_limits<double>::epsilon()) { // Avoid division by zero or near-zero
            return Vector3D(x / mag, y / mag, z / mag);
        } else {
            return Vector3D(); // Return zero vector if magnitude is too small
        }
    }

    // Vector addition
    Vector3D operator+(const Vector3D& other) const {
        return Vector3D(x + other.x, y + other.y, z + other.z);
    }

    // Vector subtraction
    Vector3D operator-(const Vector3D& other) const {
        return Vector3D(x - other.x, y - other.y, z - other.z);
    }

    // Scalar multiplication
    Vector3D operator*(double scalar) const {
        return Vector3D(x * scalar, y * scalar, z * scalar);
    }

    // Scalar division
    Vector3D operator/(double scalar) const {
        if (std::abs(scalar) > std::numeric_limits<double>::epsilon()) {
             return Vector3D(x / scalar, y / scalar, z / scalar);
        } else {
            // Handle division by zero or near-zero - return zero vector or throw?
            // Returning zero vector for simplicity here.
            return Vector3D();
        }
    }

    // Compound assignment operators
    Vector3D& operator+=(const Vector3D& other) {
        x += other.x;
        y += other.y;
        z += other.z;
        return *this;
    }

    Vector3D& operator-=(const Vector3D& other) {
        x -= other.x;
        y -= other.y;
        z -= other.z;
        return *this;
    }

    Vector3D& operator*=(double scalar) {
        x *= scalar;
        y *= scalar;
        z *= scalar;
        return *this;
    }

     Vector3D& operator/=(double scalar) {
        if (std::abs(scalar) > std::numeric_limits<double>::epsilon()) {
            x /= scalar;
            y /= scalar;
            z /= scalar;
        } else {
            // Handle division by zero - set to zero or handle error
            x = 0.0; y = 0.0; z = 0.0;
        }
        return *this;
    }

};

// Allow scalar multiplication from the left (scalar * vector)
inline Vector3D operator*(double scalar, const Vector3D& vec) {
    return vec * scalar;
}


#endif // VECTOR3D_H
