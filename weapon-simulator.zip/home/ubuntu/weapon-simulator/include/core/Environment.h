#ifndef ENVIRONMENT_H
#define ENVIRONMENT_H

#include "core/Vector3D.h"

struct Environment {
    Vector3D wind = {0.0, 0.0, 0.0}; // Wind velocity vector (m/s)
    double gravity = 9.81; // Acceleration due to gravity (m/s^2)
    double airDensity = 1.225; // Air density at sea level (kg/m^3) - for drag calculations
    // Add other factors like temperature, humidity if needed for more complex models

    Environment(Vector3D w = {0.0, 0.0, 0.0}, double g = 9.81, double density = 1.225)
        : wind(w), gravity(g), airDensity(density) {}
};

#endif // ENVIRONMENT_H
