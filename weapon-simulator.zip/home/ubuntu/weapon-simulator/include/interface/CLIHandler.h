#ifndef CLI_HANDLER_H
#define CLI_HANDLER_H

#include <vector>
#include <memory>
#include <map>
#include <string>

// Include full definitions needed for member variables
#include "core/Target.h"
#include "core/Environment.h"

// Forward declarations for pointers/references
class Weapon;
class SimulationEngine;

class CLIHandler {
private:
    std::vector<std::unique_ptr<Weapon>> designedWeapons; // Store created weapon designs
    std::unique_ptr<SimulationEngine> simEngine;
    Environment currentEnvironment; // Now Environment is fully defined
    Target currentTarget;           // Now Target is fully defined
    // Potentially a WeaponFactory instance here

    // Main menu and loop
    void displayMainMenu() const;
    void processMainMenuChoice(int choice);

    // Sub-menus and actions
    void handleWeaponDesign();
    void handleViewWeapons() const;
    // void handleSelectWeapon() const; // Maybe select weapon for simulation/comparison
    void handleRunSimulation();
    void handleConfigureEnvironment();
    void handleConfigureTarget();
    void handleCompareWeapons() const;

    // Helper methods for input
    int getUserChoice(int minChoice, int maxChoice) const;
    double getUserDouble(const std::string& prompt) const;
    int getUserInt(const std::string& prompt) const;
    std::string getUserString(const std::string& prompt) const;

    // Weapon creation helpers (could be moved to a WeaponDesigner class)
    std::unique_ptr<Weapon> createFirearm();
    std::unique_ptr<Weapon> createExplosive();
    std::unique_ptr<Weapon> createMissile();
    std::unique_ptr<Weapon> createLaserWeapon();
    // void addAttachments(Weapon& weapon);

public:
    CLIHandler();
    ~CLIHandler();

    // Start the main CLI loop
    void run();
};

#endif // CLI_HANDLER_H
